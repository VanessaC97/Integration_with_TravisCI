import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.Assertions;

public class calculatorTest {

    @Test
    void test1() {

        Assertions.assertEquals(Calculator.subtractTwoNumbers(2,1), 1);
    }


}
