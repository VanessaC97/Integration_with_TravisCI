public class Calculator {

    static int subtractTwoNumbers(int firstNumber, int secondNumber){
        return firstNumber - secondNumber;
    }
}


